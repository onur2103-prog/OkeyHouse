package com.example.okeyhouse.engine

import kotlin.random.Random

enum class Phase { DRAW, DISCARD, FINISHED }

/**
 * NORMAL: 4 dizi + çift. OKEY: aynı bitişte elde gerçek okey taşı var.
 * CIFTE: 7 çift ile bitiş.
 */
enum class WinType { NORMAL, OKEY, CIFTE }

/**
 * Oyun durumu. Tüm oyuncuların eli burada tutulur; ağ üzerinden ev sahibi
 * bu durumu tek kaynak olarak yönetir.
 * discards listesinin son elemanı en üstteki atılan taştır.
 * discardSeats, her atılan taşı atan oyuncunun koltuğunu tutar (discards ile aynı sırada).
 */
data class GameState(
    val hands: List<List<Tile>>,
    val pile: List<Tile>,
    val discards: List<Tile>,
    val indicator: Tile,
    val turn: Int,
    val phase: Phase,
    val winner: Int? = null,
    val winType: WinType? = null,
    val discardSeats: List<Int> = emptyList(),
    /** Her oyuncunun puanı. Başlangıç puanından düşer. */
    val scores: List<Int> = emptyList(),
    val startScore: Int = 0,
    /** Bitiren oyuncunun ıstaka dizilimi (22 yuva, boş yuva null). Yalnızca tur bitince dolar. */
    val layout: List<Int?> = emptyList(),
) {
    val okey: Pair<TileColor, Int>
        get() = TileSet.okeyOf(indicator)
}

sealed interface Move {
    data object DrawFromPile : Move
    data object DrawFromDiscard : Move
    data class Discard(val tileId: Int) : Move
}

object OkeyEngine {
    const val PLAYERS = 4
    private const val STARTER_HAND = 15
    private const val HAND = 14

    /** Yeni oyun dağıtır. Oyuncu 0 (başlangıç) 15 taşla başlar ve hemen atar. */
    fun newGame(random: Random = Random.Default, startScore: Int = 0): GameState {
        val ids = (0 until 106).shuffled(random).toMutableList()
        // Gösterge sahte okey olamaz
        val indicatorId = ids.first { it < TileSet.REAL_COUNT }
        ids.remove(indicatorId)

        val deck = ids.map { TileSet.byId(it) }.toMutableList()
        val hands = List(PLAYERS) { p ->
            val size = if (p == 0) STARTER_HAND else HAND
            List(size) { deck.removeAt(0) }
        }
        return GameState(
            hands = hands,
            pile = deck,
            discards = emptyList(),
            indicator = TileSet.byId(indicatorId),
            turn = 0,
            phase = Phase.DISCARD,
            scores = List(PLAYERS) { startScore },
            startScore = startScore,
        )
    }

    /** Aynı maçın sonraki turu: yeni dağıtım, puanlar korunur. */
    fun nextRound(prev: GameState, random: Random = Random.Default): GameState =
        newGame(random, prev.startScore).copy(scores = prev.scores)

    /** Normal, okey ve çifte bitişlerinde rakiplerin kaybettiği puan. */
    private fun penalty(t: WinType): Int = when (t) {
        WinType.NORMAL -> 1
        WinType.OKEY -> 2
        WinType.CIFTE -> 3
    }

    /** Hamle geçerliyse yeni durumu döndürür, değilse null. */
    fun apply(s: GameState, player: Int, move: Move): GameState? {
        if (s.phase == Phase.FINISHED || player != s.turn) return null
        return when (move) {
            Move.DrawFromPile -> {
                if (s.phase != Phase.DRAW || s.pile.isEmpty()) return null
                s.copy(
                    hands = s.hands.replaceAt(player, s.hands[player] + s.pile.first()),
                    pile = s.pile.drop(1),
                    phase = Phase.DISCARD
                )
            }

            Move.DrawFromDiscard -> {
                if (s.phase != Phase.DRAW || s.discards.isEmpty()) return null
                s.copy(
                    hands = s.hands.replaceAt(player, s.hands[player] + s.discards.last()),
                    discards = s.discards.dropLast(1),
                    discardSeats = s.discardSeats.dropLast(1),
                    phase = Phase.DISCARD
                )
            }

            is Move.Discard -> {
                if (s.phase != Phase.DISCARD) return null
                val tile = s.hands[player].firstOrNull { it.id == move.tileId } ?: return null
                val rest = s.hands[player] - tile
                val newHands = s.hands.replaceAt(player, rest)
                val newDiscards = s.discards + tile
                val newSeats = s.discardSeats + player

                val okey = s.okey
                if (WinChecker.canWin(rest, okey)) {
                    val type = when {
                        WinChecker.isSevenPairs(rest, okey) -> WinType.CIFTE
                        // Okey, elde (atılan taş dahil) bulunuyorsa okeyle bitiş sayılır
                        s.hands[player].any { !it.isFake && TileSet.isJoker(it, okey) } -> WinType.OKEY
                        else -> WinType.NORMAL
                    }
                    return s.copy(
                        hands = newHands,
                        discards = newDiscards,
                        discardSeats = newSeats,
                        phase = Phase.FINISHED,
                        winner = player,
                        winType = type,
                        scores = s.scores.mapIndexed { i, sc -> if (i == player) sc else sc - penalty(type) },
                    )
                }
                // Deste bitince oyun berabere biter
                if (s.pile.isEmpty()) {
                    return s.copy(
                        hands = newHands,
                        discards = newDiscards,
                        discardSeats = newSeats,
                        phase = Phase.FINISHED,
                        winner = null
                    )
                }
                s.copy(
                    hands = newHands,
                    discards = newDiscards,
                    discardSeats = newSeats,
                    // Saat yönünün tersine sıra
                    turn = (player + PLAYERS - 1) % PLAYERS,
                    phase = Phase.DRAW
                )
            }
        }
    }

    private fun <T> List<T>.replaceAt(index: Int, value: T): List<T> =
        mapIndexed { i, old -> if (i == index) value else old }
}
