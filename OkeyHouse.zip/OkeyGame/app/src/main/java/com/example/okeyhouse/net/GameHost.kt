package com.example.okeyhouse.net

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import com.example.okeyhouse.engine.Bot
import com.example.okeyhouse.engine.GameState
import com.example.okeyhouse.engine.Move
import com.example.okeyhouse.engine.OkeyEngine
import com.example.okeyhouse.engine.Phase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.BufferedReader
import java.io.IOException

/**
 * Ev sahibi. Koltuk 0 her zaman ev sahibindedir.
 * Boş koltuklar oyun başlayınca botla dolar.
 * Bağlantısı kopan oyuncunun koltuğu [RECONNECT_WINDOW_MS] boyunca boş tutulur;
 * oyuncu aynı oturum kimliğiyle dönerse koltuğuna geri oturur, dönmezse bot devralır.
 *
 * Tüm durum değişiklikleri [mutex] altında yapılır.
 */
class GameHost(
    private val adapter: BluetoothAdapter?,
    hostName: String,
    private val scope: CoroutineScope,
) {
    private val mutex = Mutex()
    private val names = mutableListOf(sanitizeName(hostName))
    private val links = mutableMapOf<Int, Link>()           // bağlı insan oyuncular
    private val tokens = mutableMapOf<Int, String>()        // koltuk -> oturum kimliği
    private val waiting = mutableMapOf<Int, Job>()          // bağlantısı kopan, dönmesi beklenen koltuklar
    private var server: BluetoothServerSocket? = null
    private var game: GameState? = null

    private val _lobby = MutableStateFlow(names.toList())
    val lobby: StateFlow<List<String>> = _lobby.asStateFlow()

    private val _view = MutableStateFlow<GameView?>(null)
    val view: StateFlow<GameView?> = _view.asStateFlow()

    /** Bekleme odasını açar. İstemciler eşleşmiş cihaz listesinden bağlanır. */
    @SuppressLint("MissingPermission")
    fun openLobby() {
        scope.launch(Dispatchers.IO) {
            val bt = adapter ?: return@launch
            val srv = try {
                bt.listenUsingRfcommWithServiceRecord(SERVICE_NAME, SERVICE_UUID)
            } catch (e: IOException) {
                return@launch
            }
            server = srv
            while (isActive) {
                val socket = try {
                    srv.accept()
                } catch (e: IOException) {
                    break
                }
                scope.launch(Dispatchers.IO) { handshake(socket) }
            }
        }
    }

    /** Oyunu başlatır. Boş koltuklar botla dolar, artık yeni oyuncu kabul edilmez. */
    suspend fun start() {
        mutex.withLock {
            if (game != null) return
            runCatching { server?.close() }
            while (names.size < MAX_PLAYERS) names.add("Bot ${names.size}")
            val fresh = OkeyEngine.newGame()
            game = fresh
            _lobby.value = names.toList()
            broadcast(fresh)
        }
        scope.launch(Dispatchers.IO) { gameLoop() }
    }

    /** Ev sahibinin kendi hamlesi. */
    fun playLocal(move: Move) {
        scope.launch { mutex.withLock { applyMove(0, move) } }
    }

    fun close() {
        scope.launch(Dispatchers.IO) {
            runCatching { server?.close() }
            mutex.withLock {
                links.values.forEach { it.close() }
                waiting.values.forEach { it.cancel() }
            }
        }
    }

    private suspend fun handshake(socket: BluetoothSocket) {
        val reader = socket.inputStream.bufferedReader()
        val link = Link(socket, socket.outputStream.bufferedWriter())

        val join = readWire(reader) as? Wire.Join
        if (join == null) {
            link.close()
            return
        }

        val seat = mutex.withLock {
            val returning = tokens.entries.firstOrNull { it.value == join.token && it.key in waiting }?.key
            if (returning != null) {
                // Aynı oyuncu geri döndü: eski bağlantıyı kapat, koltuğa geri oturt
                waiting.remove(returning)?.cancel()
                links.remove(returning)?.close()
                links[returning] = link
                link.send(Wire.Seat(returning))
                sendCurrent(link, returning)
                publishLobby()
                returning
            } else if (game != null || names.size >= MAX_PLAYERS) {
                link.send(Wire.Error(if (game != null) "Oyun başladı" else "Masa dolu"))
                link.close()
                return
            } else {
                val newSeat = names.size
                names.add(sanitizeName(join.name))
                tokens[newSeat] = join.token
                links[newSeat] = link
                link.send(Wire.Seat(newSeat))
                sendCurrent(link, newSeat)
                publishLobby()
                newSeat
            }
        }

        readLoop(seat, reader)

        mutex.withLock {
            // Bu arada aynı koltuğa yeni bağlantı geldiyse dokunma
            if (links[seat] !== link) return
            links.remove(seat)
            waiting[seat] = scope.launch(Dispatchers.IO) {
                delay(RECONNECT_WINDOW_MS)
                mutex.withLock {
                    if (waiting.remove(seat) != null) {
                        names[seat] = "${names[seat]} (ayrıldı)"
                        publishLobby()
                    }
                }
            }
            publishLobby()
        }
        link.close()
    }

    private suspend fun readLoop(seat: Int, reader: BufferedReader) {
        while (true) {
            val wire = readWire(reader) ?: break
            if (wire is Wire.Play) {
                mutex.withLock { applyMove(seat, wire.move) }
            }
        }
    }

    private suspend fun gameLoop() {
        while (true) {
            delay(BOT_DELAY_MS)
            mutex.withLock {
                val s = game ?: return
                if (s.phase == Phase.FINISHED) return
                if (!isHuman(s.turn)) applyMove(s.turn, Bot.chooseMove(s, s.turn))
            }
        }
    }

    /** Bağlı ya da geri dönmesi beklenen oyuncu. Bu koltukta bot oynamaz. */
    private fun isHuman(seat: Int): Boolean = seat == 0 || seat in links || seat in waiting

    /** Mutex altında çağrılmalı. */
    private fun applyMove(seat: Int, move: Move) {
        val s = game ?: return
        val next = OkeyEngine.apply(s, seat, move) ?: return
        game = next
        broadcast(next)
    }

    /** Mutex altında çağrılmalı. Her oyuncuya kendi görünümünü gönderir. */
    private fun broadcast(s: GameState) {
        val currentNames = names.toList()
        _view.value = s.viewFor(0, currentNames)
        for ((seat, link) in links) {
            link.send(Wire.State(s.viewFor(seat, currentNames)))
        }
    }

    /** Mutex altında çağrılmalı. Yeni ya da geri dönen oyuncuya mevcut durumu gönderir. */
    private fun sendCurrent(link: Link, seat: Int) {
        val s = game
        if (s != null) {
            link.send(Wire.State(s.viewFor(seat, names.toList())))
        } else {
            link.send(Wire.Lobby(names.toList()))
        }
    }

    /** Mutex altında çağrılmalı. */
    private fun publishLobby() {
        val currentNames = names.toList()
        _lobby.value = currentNames
        for (link in links.values) link.send(Wire.Lobby(currentNames))
    }

    private companion object {
        const val BOT_DELAY_MS = 2_000L
        const val RECONNECT_WINDOW_MS = 120_000L
    }
}
