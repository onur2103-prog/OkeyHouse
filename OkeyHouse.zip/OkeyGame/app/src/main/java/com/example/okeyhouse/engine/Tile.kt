package com.example.okeyhouse.engine

enum class TileColor { RED, BLUE, BLACK, YELLOW }

/**
 * id: 0..103 gerçek taşlar (2 kopya x 4 renk x 13 sayı), 104..105 sahte okey.
 * Taş yalnızca id ile tanımlanır; Bluetooth üzerinden sadece id gönderilir.
 */
data class Tile(
    val id: Int,
    val color: TileColor,
    val value: Int,
    val isFake: Boolean = false
)

object TileSet {
    const val REAL_COUNT = 104
    const val FAKE_COUNT = 2

    val ALL: List<Tile> = (0 until REAL_COUNT).map { id ->
        Tile(id, TileColor.entries[(id % 52) / 13], id % 13 + 1)
    } + List(FAKE_COUNT) { i ->
        Tile(REAL_COUNT + i, TileColor.BLACK, 0, isFake = true)
    }

    fun byId(id: Int): Tile = ALL[id]

    /** Gösterge taşının bir üstü okey olur; 13'ten sonra 1 gelir. */
    fun okeyOf(indicator: Tile): Pair<TileColor, Int> =
        indicator.color to (if (indicator.value == 13) 1 else indicator.value + 1)

    /** Okey taşı ve sahte okey, eşleşmek istediği her taşın yerine geçer. */
    fun isJoker(t: Tile, okey: Pair<TileColor, Int>): Boolean =
        t.isFake || (t.color == okey.first && t.value == okey.second)
}
