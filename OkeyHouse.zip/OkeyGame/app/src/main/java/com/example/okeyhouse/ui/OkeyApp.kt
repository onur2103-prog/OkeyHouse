package com.example.okeyhouse.ui

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.okeyhouse.engine.Move
import com.example.okeyhouse.engine.Phase
import com.example.okeyhouse.engine.Tile
import com.example.okeyhouse.engine.TileColor
import com.example.okeyhouse.engine.TileSet
import com.example.okeyhouse.net.GameClient
import com.example.okeyhouse.net.GameHost
import com.example.okeyhouse.net.GameView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private enum class RoomMode { SOLO, HOST, CLIENT }

/** Açık olan masa. Tek kişilik, ev sahibi ya da istemci için ortak arayüz. */
private class Room(
    val mode: RoomMode,
    val view: StateFlow<GameView?>,
    val lobby: StateFlow<List<String>>,
    val onStart: () -> Unit,
    val onMove: (Move) -> Unit,
    val onLeave: () -> Unit,
    val status: StateFlow<String>? = null,
)

/** Sürüklenen kaynak: ıstakadaki bir taş, deste ya da son atılan taş. */
private sealed interface DragSrc {
    data class Hand(val id: Int) : DragSrc
    data object Pile : DragSrc
    data object Discard : DragSrc
}

/** Sürükleme durumu. Pencere koordinatlarında tutulur. */
private class DragController {
    var src by mutableStateOf<DragSrc?>(null)
    var tile by mutableStateOf<Tile?>(null)
    var pos by mutableStateOf(Offset.Zero)
    var size by mutableStateOf(Size.Zero)
    var rootOrigin by mutableStateOf(Offset.Zero)
    var rackRect by mutableStateOf(Rect.Zero)
    var discardRect by mutableStateOf(Rect.Zero)
    var onDrop: (DragSrc, Offset) -> Unit = { _, _ -> }

    fun begin(s: DragSrc, t: Tile?, at: Offset, sz: Size) {
        src = s
        tile = t
        pos = at
        size = sz
    }

    fun move(delta: Offset) {
        pos += delta
    }

    fun end() {
        val s = src
        if (s != null) onDrop(s, pos + Offset(size.width / 2f, size.height / 2f))
        src = null
        tile = null
    }

    fun cancel() {
        src = null
        tile = null
    }
}

private class Geo {
    var pos = Offset.Zero
    var size = Size.Zero
}

/** Uygulamanın kök composable'ı. */
@Composable
fun OkeyApp(adapter: BluetoothAdapter?, scope: CoroutineScope) {
    val uiScope = rememberCoroutineScope()
    var name by rememberSaveable { mutableStateOf("Oyuncu") }
    var room by remember { mutableStateOf<Room?>(null) }
    var joining by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val action = pending
        pending = null
        if (results.values.all { it } && action != null) action() else error = "Bluetooth izni verilmedi."
    }

    fun withBluetooth(action: () -> Unit) {
        val perms = requiredPermissions()
        if (perms.isEmpty()) {
            action()
        } else {
            pending = action
            permissionLauncher.launch(perms)
        }
    }

    val current = room
    when {
        current != null -> RoomScreen(current)

        joining && adapter != null -> JoinScreen(
            adapter = adapter,
            onBack = { joining = false },
            onPick = { device ->
                val client = GameClient(scope)
                uiScope.launch {
                    if (client.connect(device, name)) {
                        joining = false
                        room = Room(
                            mode = RoomMode.CLIENT,
                            view = client.view,
                            lobby = client.lobby,
                            onStart = {},
                            onMove = client::play,
                            onLeave = {
                                client.disconnect()
                                room = null
                                error = null
                            },
                            status = client.status,
                        )
                    } else {
                        error = client.status.value
                    }
                }
            },
            error = error,
        )

        else -> MenuScreen(
            name = name,
            onNameChange = { name = it.take(16) },
            hasBluetooth = adapter != null,
            error = error,
            onSolo = {
                val host = GameHost(adapter, name, scope)
                scope.launch { host.start() }
                room = Room(
                    mode = RoomMode.SOLO,
                    view = host.view,
                    lobby = host.lobby,
                    onStart = {},
                    onMove = host::playLocal,
                    onLeave = {
                        host.close()
                        room = null
                    },
                )
            },
            onHost = {
                withBluetooth {
                    val host = GameHost(adapter, name, scope)
                    host.openLobby()
                    room = Room(
                        mode = RoomMode.HOST,
                        view = host.view,
                        lobby = host.lobby,
                        onStart = { scope.launch { host.start() } },
                        onMove = host::playLocal,
                        onLeave = {
                            host.close()
                            room = null
                        },
                    )
                }
            },
            onJoin = { withBluetooth { joining = true } },
        )
    }
}

@Composable
private fun MenuScreen(
    name: String,
    onNameChange: (String) -> Unit,
    hasBluetooth: Boolean,
    error: String?,
    onSolo: () -> Unit,
    onHost: () -> Unit,
    onJoin: () -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("OkeyHouse", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = name,
            onValueChange = onNameChange,
            label = { Text("Adın") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(0.6f)
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = onSolo, modifier = Modifier.fillMaxWidth(0.6f)) {
            Text("Tek kişilik (botlarla)")
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = onHost, enabled = hasBluetooth, modifier = Modifier.fillMaxWidth(0.6f)) {
            Text("Masa kur (Bluetooth)")
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = onJoin, enabled = hasBluetooth, modifier = Modifier.fillMaxWidth(0.6f)) {
            Text("Masaya katıl (Bluetooth)")
        }
        error?.let {
            Spacer(Modifier.height(12.dp))
            Text(it, color = Color(0xFFEF9A9A))
        }
    }
}

@Composable
private fun JoinScreen(
    adapter: BluetoothAdapter,
    onBack: () -> Unit,
    onPick: (BluetoothDevice) -> Unit,
    error: String?,
) {
    val devices = remember { GameClient.pairedDevices(adapter) }
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Eşleşmiş cihazlar", style = MaterialTheme.typography.titleLarge)
        Text(
            "Ev sahibi telefonu seç. Telefonlar önce sistem Bluetooth ayarlarından eşleştirilmiş olmalı.",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(8.dp))
        if (devices.isEmpty()) Text("Eşleşmiş cihaz yok.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(devices) { device ->
                Button(onClick = { onPick(device) }, modifier = Modifier.fillMaxWidth()) {
                    Text(device.name ?: device.address)
                }
            }
        }
        error?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = Color(0xFFEF9A9A))
        }
        Spacer(Modifier.weight(1f))
        TextButton(onClick = onBack) { Text("Geri") }
    }
}

@Composable
private fun RoomScreen(room: Room) {
    val view by room.view.collectAsState()
    val lobby by room.lobby.collectAsState()
    val statusFlow = room.status ?: remember { MutableStateFlow("") }
    val statusText by statusFlow.collectAsState()
    val v = view
    Box(modifier = Modifier.fillMaxSize()) {
        if (v == null) {
            LobbyContent(room, lobby)
        } else {
            TableScreen(v, room.onMove, onLeave = room.onLeave)
        }
        if (statusText.isNotEmpty()) {
            Text(
                statusText,
                color = Color(0xFFFFCC80),
                modifier = Modifier.align(Alignment.TopCenter).padding(8.dp)
            )
        }
    }
}

@Composable
private fun LobbyContent(room: Room, lobby: List<String>) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Masa", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        lobby.forEach { Text(it) }
        Spacer(Modifier.height(16.dp))
        when (room.mode) {
            RoomMode.SOLO -> Text("Hazırlanıyor…")
            RoomMode.HOST -> Button(onClick = room.onStart) {
                Text("Oyunu başlat (boş yerler bot olur)")
            }
            RoomMode.CLIENT -> Text("Ev sahibinin oyunu başlatması bekleniyor…")
        }
        Spacer(Modifier.height(12.dp))
        TextButton(onClick = room.onLeave) { Text("Çık") }
    }
}

@Composable
private fun TableScreen(v: GameView, onMove: (Move) -> Unit, onLeave: () -> Unit) {
    val okey = TileSet.okeyOf(v.indicator)
    val isJoker = { t: Tile -> TileSet.isJoker(t, okey) }
    val finished = v.phase == Phase.FINISHED
    val myTurn = !finished && v.turn == v.seat
    val canDiscard = myTurn && v.phase == Phase.DISCARD
    val canDraw = myTurn && v.phase == Phase.DRAW
    var celebrationDone by remember { mutableStateOf(false) }

    // Taş sırası: kullanıcı sürükleyerek değiştirebilir, yeni taşlar sona eklenir
    var order by remember { mutableStateOf<List<Int>>(emptyList()) }
    val known = v.hand.map { it.id }
    val hand = (order.filter { it in known } + known.filter { it !in order })
        .map { id -> v.hand.first { it.id == id } }

    val ctl = remember { DragController() }
    ctl.onDrop = { src, center ->
        when (src) {
            is DragSrc.Hand -> {
                if (canDiscard && ctl.discardRect.contains(center)) {
                    // Taş ortadaki alana bırakılırsa atılır
                    onMove(Move.Discard(src.id))
                } else if (ctl.rackRect.contains(center)) {
                    val ids = hand.map { it.id }.toMutableList()
                    ids.remove(src.id)
                    val row = if (center.y < ctl.rackRect.center.y) 0 else 1
                    val col = ((center.x - ctl.rackRect.left) / (ctl.rackRect.width / 8f)).toInt().coerceIn(0, 7)
                    ids.add((row * 8 + col).coerceIn(0, ids.size), src.id)
                    order = ids
                }
            }
            DragSrc.Pile -> if (canDraw && ctl.rackRect.contains(center)) onMove(Move.DrawFromPile)
            DragSrc.Discard -> if (canDraw && ctl.rackRect.contains(center)) onMove(Move.DrawFromDiscard)
        }
    }

    val left = (v.seat + 1) % 4
    val top = (v.seat + 2) % 4
    val right = (v.seat + 3) % 4

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.radialGradient(listOf(Color(0xFF2E8B57), Color(0xFF145A32))))
            .onGloballyPositioned { ctl.rootOrigin = it.positionInWindow() }
    ) {
        val tw = minOf(38.dp, (maxWidth * 0.66f - 52.dp) / 8)
        val rackWidth = tw * 8 + 52.dp
        val trayH = (tw * 1.35f + 14.dp) / 0.8f
        val rackHeight = trayH * 2 + 6.dp
        val smallW = tw * 0.62f
        val cw = tw * 1.2f

        // Üst oyuncu ve atılan taşları
        SeatPlate(
            name = v.names[top],
            count = v.handSizes[top],
            active = !finished && v.turn == top,
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 6.dp)
        )
        SeatStack(
            v, top, smallW, vertical = false, ctl, canDraw, isJoker,
            Modifier.align(Alignment.TopCenter).padding(top = 52.dp)
        )

        // Sol oyuncu ve atılan taşları
        SeatPlate(
            name = v.names[left],
            count = v.handSizes[left],
            active = !finished && v.turn == left,
            modifier = Modifier.align(Alignment.CenterStart).padding(start = 6.dp)
        )
        SeatStack(
            v, left, smallW, vertical = true, ctl, canDraw, isJoker,
            Modifier.align(Alignment.CenterStart).padding(start = 110.dp)
        )

        // Sağ oyuncu ve atılan taşları
        SeatPlate(
            name = v.names[right],
            count = v.handSizes[right],
            active = !finished && v.turn == right,
            modifier = Modifier.align(Alignment.CenterEnd).padding(end = 6.dp)
        )
        SeatStack(
            v, right, smallW, vertical = true, ctl, canDraw, isJoker,
            Modifier.align(Alignment.CenterEnd).padding(end = 110.dp)
        )

        // Kendi atılan taşlarım (ıstakanın üstünde, solda)
        SeatStack(
            v, v.seat, smallW, vertical = false, ctl, canDraw, isJoker,
            Modifier.align(Alignment.BottomStart).padding(start = 12.dp, bottom = rackHeight + 8.dp)
        )

        // Okey bilgisi
        Text(
            "Okey: ${colorNameTr(okey.first)} ${okey.second}",
            color = Color.White,
            fontSize = 11.sp,
            modifier = Modifier.align(Alignment.TopStart).padding(8.dp)
        )

        // Durum ve çıkış
        Row(
            modifier = Modifier.align(Alignment.TopEnd).padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = statusLine(v, myTurn),
                color = Color.White,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            TextButton(onClick = onLeave) {
                Text(if (finished) "Menü" else "Çık", color = Color(0xFFE1BEE7), fontSize = 12.sp)
            }
        }

        // Orta alan: gösterge ve deste yan yana. Taş sürüklenirken bu alan atma hedefidir.
        val dropping = canDiscard && ctl.src is DragSrc.Hand
        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .onGloballyPositioned { ctl.discardRect = it.boundsInWindow() }
                .background(
                    if (dropping) Color(0x33FFFFFF) else Color.Transparent,
                    RoundedCornerShape(14.dp)
                )
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (dropping) {
                Text("Atmak için buraya bırak", color = Color.White, fontSize = 11.sp)
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                TileView(v.indicator, joker = false, width = cw * 0.8f)
                Draggable(ctl, DragSrc.Pile, null, enabled = canDraw && v.pileSize > 0) {
                    DeckTile(count = v.pileSize, width = cw)
                }
            }
        }

        // İpucu satırı
        Text(
            hintLine(v, myTurn),
            color = Color(0xFFE8F5E9),
            fontSize = 11.sp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = rackHeight + 8.dp)
        )

        // Çift katlı ıstaka: iki ayrı sarı tepsi
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .width(rackWidth)
                .height(rackHeight)
                .onGloballyPositioned { ctl.rackRect = it.boundsInWindow() },
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            RackTray(rackWidth, trayH) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    hand.take(8).forEach { t -> RackTile(t, tw, ctl, isJoker) }
                }
            }
            RackTray(rackWidth, trayH) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    hand.drop(8).forEach { t -> RackTile(t, tw, ctl, isJoker) }
                }
            }
        }

        // Sürüklenen taş (en üstte)
        val src = ctl.src
        if (src != null) {
            val wDp = with(LocalDensity.current) { ctl.size.width.toDp() }
            val mod = Modifier.offset {
                IntOffset(
                    (ctl.pos.x - ctl.rootOrigin.x).roundToInt(),
                    (ctl.pos.y - ctl.rootOrigin.y).roundToInt()
                )
            }
            val t = ctl.tile
            if (t != null) {
                TileView(t, isJoker(t), width = wDp, modifier = mod)
            } else {
                TileBack(width = wDp, modifier = mod)
            }
        }

        val winner = v.winner
        val winType = v.winType
        if (finished && winner != null && winType != null && !celebrationDone) {
            WinCelebration(
                winType = winType,
                playerName = v.names[winner],
                isMe = winner == v.seat,
                onDismiss = { celebrationDone = true }
            )
        }
    }
}

/**
 * Tek sıralık sarı ıstaka tepsisi: üstte sarı gövde, altta iki uçta kahverengi ayak.
 * Taşlar gövdenin içinde ortalanır.
 */
@Composable
private fun RackTray(width: Dp, height: Dp, content: @Composable () -> Unit) {
    val bodyShape = RoundedCornerShape(4.dp)
    Box(modifier = Modifier.width(width).height(height)) {
        Canvas(modifier = Modifier.matchParentSize()) {
            val brown = Color(0xFF6B3A1E)
            val h = size.height
            val w = size.width
            val footTop = h * 0.78f
            val left = Path().apply {
                moveTo(0f, h)
                lineTo(w * 0.10f, h)
                lineTo(w * 0.02f, footTop)
                close()
            }
            val right = Path().apply {
                moveTo(w, h)
                lineTo(w * 0.90f, h)
                lineTo(w * 0.98f, footTop)
                close()
            }
            drawPath(left, brown)
            drawPath(right, brown)
        }
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .fillMaxHeight(0.8f)
                .shadow(3.dp, bodyShape)
                .clip(bodyShape)
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFFF5B946), Color(0xFFE09A2A), Color(0xFFC77F1C))
                    )
                )
                .border(1.dp, Color(0xFF9A5B12), bodyShape),
            contentAlignment = Alignment.Center
        ) {
            content()
        }
    }
}

@Composable
private fun RackTile(t: Tile, width: Dp, ctl: DragController, isJoker: (Tile) -> Boolean) {
    val src = DragSrc.Hand(t.id)
    Draggable(ctl, src, t, enabled = true) {
        TileView(t, isJoker(t), width = width, ghost = ctl.src == src)
    }
}

/**
 * Bir oyuncunun atılan taşları, koltuğunun yanında yığılı durur.
 * En son atılan taş (masadaki son hareket) yeşil çerçeveyle işaretlenir ve sıra sendeyken alınabilir.
 */
@Composable
private fun SeatStack(
    v: GameView,
    seat: Int,
    width: Dp,
    vertical: Boolean,
    ctl: DragController,
    canDraw: Boolean,
    isJoker: (Tile) -> Boolean,
    modifier: Modifier,
) {
    // Her oyuncunun yanında yalnızca son attığı taş görünür; yeni taş önceki taşı kapatır
    val picks = v.discards.indices
        .filter { v.discardSeats.getOrNull(it) == seat }
        .takeLast(1)
    if (vertical) {
        Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(3.dp)) {
            picks.forEach { i -> StackTile(v, i, width, ctl, canDraw, isJoker) }
        }
    } else {
        Row(modifier = modifier, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            picks.forEach { i -> StackTile(v, i, width, ctl, canDraw, isJoker) }
        }
    }
}

@Composable
private fun StackTile(
    v: GameView,
    index: Int,
    width: Dp,
    ctl: DragController,
    canDraw: Boolean,
    isJoker: (Tile) -> Boolean,
) {
    val t = v.discards[index]
    if (index == v.discards.lastIndex) {
        Draggable(ctl, DragSrc.Discard, t, enabled = canDraw) {
            TileView(t, isJoker(t), width = width, highlight = LAST_DISCARD_COLOR)
        }
    } else {
        TileView(t, isJoker(t), width = width)
    }
}

/** Sürüklenebilir alan. Bırakıldığında [DragController] hedefi değerlendirir. */
@Composable
private fun Draggable(
    ctl: DragController,
    src: DragSrc,
    tile: Tile?,
    enabled: Boolean,
    content: @Composable () -> Unit,
) {
    val geo = remember { Geo() }
    val gesture = if (enabled) {
        Modifier.pointerInput(src, tile) {
            detectDragGestures(
                onDragStart = { ctl.begin(src, tile, geo.pos, geo.size) },
                onDrag = { _, amount -> ctl.move(amount) },
                onDragEnd = { ctl.end() },
                onDragCancel = { ctl.cancel() },
            )
        }
    } else {
        Modifier
    }
    Box(
        modifier = Modifier
            .onGloballyPositioned { c ->
                geo.pos = c.positionInWindow()
                geo.size = Size(c.size.width.toFloat(), c.size.height.toFloat())
            }
            .then(gesture)
    ) {
        content()
    }
}

@Composable
private fun SeatPlate(name: String, count: Int, active: Boolean, modifier: Modifier) {
    val shape = RoundedCornerShape(8.dp)
    Column(
        modifier = modifier
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFF8B5A2B), Color(0xFF5C3A1C))))
            .border(if (active) 2.dp else 1.dp, if (active) Color(0xFFFFD54F) else Color(0xFF3E2716), shape)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            name,
            color = Color(0xFFFFF3E0),
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text("$count taş", color = Color(0xFFD7B899), fontSize = 10.sp)
    }
}

/** Deste: üstünde kalan taş sayısı yazan krem bir taş. */
@Composable
private fun DeckTile(count: Int, width: Dp) {
    val shape = RoundedCornerShape(width * 0.14f)
    Box(
        modifier = Modifier
            .size(width, width * 1.35f)
            .shadow(3.dp, shape)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFFFFFCF2), Color(0xFFE9DDBF))))
            .border(0.8.dp, Color(0xFF8D6E4B), shape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            count.toString(),
            color = Color(0xFF212121),
            fontWeight = FontWeight.Bold,
            fontSize = (width.value * 0.42f).sp
        )
    }
}

/** Yüzü kapalı taş (sürüklenirken deste için). */
@Composable
private fun TileBack(width: Dp, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(width * 0.14f)
    Box(
        modifier = modifier
            .size(width, width * 1.35f)
            .shadow(3.dp, shape)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFF1E4D8C), Color(0xFF0D2B52))))
            .border(0.8.dp, Color(0xFF8D6E4B), shape)
    )
}

/** Gerçek görünümlü taş: krem zemin, renkli sayı ve alt kısımda nokta. */
@Composable
private fun TileView(
    tile: Tile,
    joker: Boolean,
    width: Dp,
    ghost: Boolean = false,
    highlight: Color? = null,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(width * 0.14f)
    val textColor = if (tile.isFake) Color(0xFF424242) else colorOf(tile.color)
    Box(
        modifier = modifier
            .alpha(if (ghost) 0.35f else 1f)
            .size(width, width * 1.35f)
            .shadow(3.dp, shape)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFFFFFCF2), Color(0xFFE9DDBF))))
            .border(
                if (highlight != null) 2.dp else 0.8.dp,
                highlight ?: Color(0xFF8D6E4B),
                shape
            ),
        contentAlignment = Alignment.Center
    ) {
        if (tile.isFake) {
            Text("★", color = textColor, fontWeight = FontWeight.Bold, fontSize = (width.value * 0.5f).sp)
        } else {
            Text(
                tile.value.toString(),
                color = textColor,
                fontWeight = FontWeight.Bold,
                fontSize = (width.value * 0.48f).sp
            )
            Canvas(
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = width * 0.1f)
                    .size(width * 0.22f)
            ) {
                drawCircle(color = textColor)
                drawCircle(color = Color.White.copy(alpha = 0.45f), radius = size.minDimension / 4f)
            }
        }
        if (joker && !tile.isFake) {
            Text(
                "O",
                color = Color(0xFF6A1B9A),
                fontSize = (width.value * 0.22f).sp,
                modifier = Modifier.align(Alignment.TopStart).padding(2.dp)
            )
        }
    }
}

private val LAST_DISCARD_COLOR = Color(0xFF7CFC00)

private fun statusLine(v: GameView, myTurn: Boolean): String = when {
    v.phase == Phase.FINISHED && v.winner == null -> "Berabere"
    v.phase == Phase.FINISHED -> "${v.names[v.winner!!]} kazandı"
    myTurn -> "Sıra sende"
    else -> "Sıra ${v.names[v.turn]}"
}

private fun hintLine(v: GameView, myTurn: Boolean): String = when {
    v.phase == Phase.FINISHED -> ""
    !myTurn -> "Yeşil çerçeveli taş en son atılan taştır"
    v.phase == Phase.DRAW -> "Desteden ya da yeşil çerçeveli son taştan ıstakaya sürükle"
    else -> "Bir taşı sürükleyip ortadaki alana bırak"
}

private fun colorOf(c: TileColor): Color = when (c) {
    TileColor.RED -> Color(0xFFC62828)
    TileColor.BLUE -> Color(0xFF1565C0)
    TileColor.BLACK -> Color(0xFF212121)
    TileColor.YELLOW -> Color(0xFFEF8F00)
}

private fun colorNameTr(c: TileColor): String = when (c) {
    TileColor.RED -> "kırmızı"
    TileColor.BLUE -> "mavi"
    TileColor.BLACK -> "siyah"
    TileColor.YELLOW -> "sarı"
}

private fun requiredPermissions(): Array<String> =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
    } else {
        emptyArray()
    }
