package com.example.okeyhouse.ui

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.okeyhouse.engine.Move
import com.example.okeyhouse.engine.Phase
import com.example.okeyhouse.engine.Tile
import com.example.okeyhouse.engine.TileColor
import com.example.okeyhouse.engine.TileSet
import com.example.okeyhouse.net.GameClient
import com.example.okeyhouse.net.GameHost
import com.example.okeyhouse.net.GameView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

private enum class RoomMode { SOLO, HOST, CLIENT }

/** Açık olan masa. Ev sahibi, istemci ya da tek kişilik oyun için ortak arayüz. */
private class Room(
    val mode: RoomMode,
    val view: StateFlow<GameView?>,
    val lobby: StateFlow<List<String>>,
    val onStart: () -> Unit,
    val onMove: (Move) -> Unit,
    val onLeave: () -> Unit,
    val status: StateFlow<String>? = null,
)

/** Uygulamanın kök composable'ı. */
@Composable
fun OkeyApp(adapter: BluetoothAdapter?, scope: CoroutineScope) {
    val uiScope = rememberCoroutineScope()
    var name by rememberSaveable { mutableStateOf("Oyuncu") }
    var room by remember { mutableStateOf<Room?>(null) }
    var joining by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val action = pending
        pending = null
        if (results.values.all { it } && action != null) action() else error = "Bluetooth izni verilmedi."
    }

    // Bluetooth gerektiren işlemlerden önce izin ister; izin varsa doğrudan çalıştırır.
    fun withBluetooth(action: () -> Unit) {
        val perms = requiredPermissions()
        if (perms.isEmpty()) {
            action()
        } else {
            pending = action
            permissionLauncher.launch(perms)
        }
    }

    val current = room
    when {
        current != null -> RoomScreen(current)

        joining && adapter != null -> JoinScreen(
            adapter = adapter,
            onBack = { joining = false },
            onPick = { device ->
                val client = GameClient(scope)
                uiScope.launch {
                    if (client.connect(device, name)) {
                        joining = false
                        room = Room(
                            mode = RoomMode.CLIENT,
                            view = client.view,
                            lobby = client.lobby,
                            onStart = {},
                            onMove = client::play,
                            status = client.status,
                            onLeave = {
                                client.disconnect()
                                room = null
                                error = null
                            },
                        )
                    } else {
                        error = client.status.value
                    }
                }
            },
            error = error,
        )

        else -> MenuScreen(
            name = name,
            onNameChange = { name = it.take(16) },
            hasBluetooth = adapter != null,
            error = error,
            onSolo = {
                val host = GameHost(adapter, name, scope)
                scope.launch { host.start() }
                room = Room(
                    mode = RoomMode.SOLO,
                    view = host.view,
                    lobby = host.lobby,
                    onStart = {},
                    onMove = host::playLocal,
                    onLeave = {
                        host.close()
                        room = null
                    },
                )
            },
            onHost = {
                withBluetooth {
                    val host = GameHost(adapter, name, scope)
                    host.openLobby()
                    room = Room(
                        mode = RoomMode.HOST,
                        view = host.view,
                        lobby = host.lobby,
                        onStart = { scope.launch { host.start() } },
                        onMove = host::playLocal,
                        onLeave = {
                            host.close()
                            room = null
                        },
                    )
                }
            },
            onJoin = { withBluetooth { joining = true } },
        )
    }
}

@Composable
private fun MenuScreen(
    name: String,
    onNameChange: (String) -> Unit,
    hasBluetooth: Boolean,
    error: String?,
    onSolo: () -> Unit,
    onHost: () -> Unit,
    onJoin: () -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("OkeyHouse", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(
            value = name,
            onValueChange = onNameChange,
            label = { Text("Adın") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onSolo, modifier = Modifier.fillMaxWidth()) {
            Text("Tek kişilik (botlarla)")
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = onHost, enabled = hasBluetooth, modifier = Modifier.fillMaxWidth()) {
            Text("Masa kur (Bluetooth)")
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = onJoin, enabled = hasBluetooth, modifier = Modifier.fillMaxWidth()) {
            Text("Masaya katıl (Bluetooth)")
        }
        error?.let {
            Spacer(Modifier.height(16.dp))
            Text(it, color = Color(0xFFEF9A9A))
        }
    }
}

@Composable
private fun JoinScreen(
    adapter: BluetoothAdapter,
    onBack: () -> Unit,
    onPick: (BluetoothDevice) -> Unit,
    error: String?,
) {
    val devices = remember { GameClient.pairedDevices(adapter) }
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Eşleşmiş cihazlar", style = MaterialTheme.typography.titleLarge)
        Text(
            "Ev sahibi telefonu seç. Telefonlar önce sistem Bluetooth ayarlarından eşleştirilmiş olmalı.",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(12.dp))
        if (devices.isEmpty()) {
            Text("Eşleşmiş cihaz yok.")
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(devices) { device ->
                Button(onClick = { onPick(device) }, modifier = Modifier.fillMaxWidth()) {
                    Text(device.name ?: device.address)
                }
            }
        }
        error?.let {
            Spacer(Modifier.height(12.dp))
            Text(it, color = Color(0xFFEF9A9A))
        }
        Spacer(Modifier.weight(1f))
        TextButton(onClick = onBack) { Text("Geri") }
    }
}

@Composable
private fun RoomScreen(room: Room) {
    val view by room.view.collectAsState()
    val lobby by room.lobby.collectAsState()
    val v = view
    val statusFlow = room.status ?: remember { MutableStateFlow("") }
    val statusText by statusFlow.collectAsState()
    Box(modifier = Modifier.fillMaxSize()) {
        if (v == null) {
            LobbyContent(room, lobby)
        } else {
            TableScreen(v, room.onMove, onLeave = room.onLeave)
        }
        if (statusText.isNotEmpty()) {
            Text(
                statusText,
                color = Color(0xFFFFCC80),
                modifier = Modifier.align(Alignment.TopCenter).padding(8.dp)
            )
        }
    }
}

@Composable
private fun LobbyContent(room: Room, lobby: List<String>) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Masa", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))
        lobby.forEach { Text(it) }
        Spacer(Modifier.height(24.dp))
        when (room.mode) {
            RoomMode.SOLO -> Text("Hazırlanıyor…")
            RoomMode.HOST -> Button(onClick = room.onStart) {
                Text("Oyunu başlat (boş yerler bot olur)")
            }
            RoomMode.CLIENT -> Text("Ev sahibinin oyunu başlatması bekleniyor…")
        }
        Spacer(Modifier.height(16.dp))
        TextButton(onClick = room.onLeave) { Text("Çık") }
    }
}

@Composable
private fun TableScreen(v: GameView, onMove: (Move) -> Unit, onLeave: () -> Unit) {
    val okey = TileSet.okeyOf(v.indicator)
    val isJoker = { t: Tile -> TileSet.isJoker(t, okey) }
    val finished = v.phase == Phase.FINISHED
    val myTurn = !finished && v.turn == v.seat
    var selected by remember(v.hand) { mutableStateOf<Int?>(null) }
    var celebrationDone by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
            // Oyuncular
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                v.names.forEachIndexed { i, n ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                        val mark = if (!finished && i == v.turn) "▶ " else ""
                        Text(
                            text = mark + n + if (i == v.seat) " (sen)" else "",
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.labelMedium
                        )
                        Text("${v.handSizes[i]} taş", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            // Gösterge ve deste
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Gösterge ", style = MaterialTheme.typography.labelMedium)
                    TileView(v.indicator, joker = false, selected = false, size = 32.dp, onClick = null)
                }
                Text("Okey: ${okey.first.name.lowercase()} ${okey.second}", style = MaterialTheme.typography.labelMedium)
                Text("Deste: ${v.pileSize}", style = MaterialTheme.typography.labelMedium)
            }

            Spacer(Modifier.height(12.dp))
            Text("Atılanlar", style = MaterialTheme.typography.labelMedium)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                items(v.discards.takeLast(20)) { t ->
                    TileView(t, joker = isJoker(t), selected = false, size = 26.dp, onClick = null)
                }
            }

            Spacer(Modifier.weight(1f))

            // Durum satırı
            val status = when {
                finished && v.winner == null -> "Berabere, deste bitti."
                finished -> "${v.names[v.winner!!]} kazandı."
                myTurn -> "Sıra sende."
                else -> "Sıra ${v.names[v.turn]} adlı oyuncuda."
            }
            Text(status, style = MaterialTheme.typography.bodyMedium)

            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Button(
                    onClick = { onMove(Move.DrawFromPile) },
                    enabled = myTurn && v.phase == Phase.DRAW && v.pileSize > 0
                ) { Text("Desteden çek") }
                Button(
                    onClick = { onMove(Move.DrawFromDiscard) },
                    enabled = myTurn && v.phase == Phase.DRAW && v.discards.isNotEmpty()
                ) { Text("Atılandan") }
                Button(
                    onClick = {
                        selected?.let { onMove(Move.Discard(it)) }
                        selected = null
                    },
                    enabled = myTurn && v.phase == Phase.DISCARD && selected != null
                ) { Text("At") }
            }

            Spacer(Modifier.height(12.dp))
            Text("Elin", style = MaterialTheme.typography.labelMedium)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                items(v.hand) { t ->
                    TileView(
                        tile = t,
                        joker = isJoker(t),
                        selected = selected == t.id,
                        size = 40.dp,
                        onClick = { selected = if (selected == t.id) null else t.id }
                    )
                }
            }

            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onLeave, modifier = Modifier.align(Alignment.End)) {
                Text(if (finished) "Menüye dön" else "Masadan çık")
            }
        }

        val winner = v.winner
        val winType = v.winType
        if (finished && winner != null && winType != null && !celebrationDone) {
            WinCelebration(
                winType = winType,
                playerName = v.names[winner],
                onDismiss = { celebrationDone = true }
            )
        }
    }
}

/** Tek taş. Okey taşları küçük bir "O", sahte okey yıldız olarak görünür. */
@Composable
private fun TileView(
    tile: Tile,
    joker: Boolean,
    selected: Boolean,
    size: Dp,
    onClick: (() -> Unit)?,
) {
    val shape = RoundedCornerShape(6.dp)
    val textColor = if (tile.isFake) Color.DarkGray else colorOf(tile.color)
    val base = Modifier
        .size(width = size, height = size * 1.35f)
        .clip(shape)
        .background(Color(0xFFFFF8E7))
        .border(
            width = if (selected) 3.dp else 1.dp,
            color = if (selected) Color(0xFFFFD600) else Color.Gray,
            shape = shape
        )
    val clickable = if (onClick != null) base.clickable(onClick = onClick) else base

    Box(modifier = clickable, contentAlignment = Alignment.Center) {
        Text(
            text = if (tile.isFake) "★" else tile.value.toString(),
            color = textColor,
            fontWeight = FontWeight.Bold,
            fontSize = (size.value * 0.45f).sp
        )
        if (joker && !tile.isFake) {
            Text(
                text = "O",
                color = Color(0xFF6A1B9A),
                fontSize = (size.value * 0.22f).sp,
                modifier = Modifier.align(Alignment.TopStart).padding(2.dp)
            )
        }
    }
}

private fun colorOf(c: TileColor): Color = when (c) {
    TileColor.RED -> Color(0xFFC62828)
    TileColor.BLUE -> Color(0xFF1565C0)
    TileColor.BLACK -> Color(0xFF212121)
    TileColor.YELLOW -> Color(0xFFF9A825)
}

private fun requiredPermissions(): Array<String> =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
    } else {
        emptyArray()
    }
