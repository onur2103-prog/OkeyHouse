package com.example.okeyhouse.ui

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.SoundPool
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.okeyhouse.R
import com.example.okeyhouse.engine.WinType
import kotlin.random.Random

/** Kısa alkış sesi. Yalnızca normal bitirişte çalar. */
class ApplausePlayer(context: Context) {
    private val pool = SoundPool.Builder()
        .setMaxStreams(1)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()

    private var loaded = false
    private var pending = false
    private val soundId = pool.load(context, R.raw.applause, 1)

    init {
        pool.setOnLoadCompleteListener { _, id, status ->
            if (status == 0 && id == soundId) {
                loaded = true
                if (pending) play()
            }
        }
    }

    fun play() {
        if (loaded) pool.play(soundId, 1f, 1f, 1, 0, 1f) else pending = true
    }

    fun release() = pool.release()
}

/** Bitiş türüne göre paylaşılacak metin. Görsel paylaşımı ileride eklenebilir. */
fun shareWin(context: Context, playerName: String, winType: WinType) {
    val text = when (winType) {
        WinType.OKEY -> "$playerName OkeyHouse'da okey ile bitirdi! 🎉"
        WinType.CIFTE -> "$playerName OkeyHouse'da çifte (7 çift) ile bitirdi! 🎉"
        WinType.NORMAL -> "$playerName OkeyHouse'da kazandı! 🎉"
    }
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(intent, "Paylaş"))
}

/**
 * Kazanma ekranı.
 * NORMAL: alkış sesi.
 * OKEY: konfeti ve paylaş düğmesi.
 */
@Composable
fun WinCelebration(winType: WinType, playerName: String, isMe: Boolean, onDismiss: () -> Unit) {
    val context = LocalContext.current

    if (winType == WinType.NORMAL) {
        val player = remember { ApplausePlayer(context) }
        LaunchedEffect(Unit) { player.play() }
        DisposableEffect(Unit) { onDispose { player.release() } }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000000)),
        contentAlignment = Alignment.Center
    ) {
        if (winType != WinType.NORMAL) {
            ConfettiOverlay()
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = when {
                    isMe && winType == WinType.OKEY -> "Okey ile bitirdin!"
                    isMe && winType == WinType.CIFTE -> "Çifte ile bitirdin!"
                    isMe -> "Kazandın!"
                    winType == WinType.OKEY -> "$playerName okey ile bitirdi"
                    winType == WinType.CIFTE -> "$playerName çifte ile bitirdi"
                    else -> "$playerName kazandı"
                },
                color = Color.White
            )
            Column(
                modifier = Modifier.padding(top = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (isMe && winType != WinType.NORMAL) {
                    Button(onClick = { shareWin(context, playerName, winType) }) {
                        Text("Paylaş")
                    }
                }
                Button(onClick = onDismiss) { Text("Tamam") }
            }
        }
    }
}

private class Particle(
    val x0: Float,
    val y0: Float,
    val drift: Float,
    val speed: Float,
    val delay: Float,
    val color: Color,
    val radius: Float,
) {
    companion object {
        private val palette = listOf(
            Color(0xFFE53935), Color(0xFF1E88E5), Color(0xFFFDD835),
            Color(0xFF43A047), Color(0xFFFB8C00), Color(0xFF8E24AA)
        )

        fun random(rnd: Random) = Particle(
            x0 = rnd.nextFloat(),
            y0 = -0.2f + rnd.nextFloat() * 0.2f,
            drift = -0.08f + rnd.nextFloat() * 0.16f,
            speed = 0.35f + rnd.nextFloat() * 0.5f,
            delay = rnd.nextFloat() * 0.4f,
            color = palette[rnd.nextInt(palette.size)],
            radius = 6f + rnd.nextFloat() * 6f,
        )
    }
}

@Composable
private fun ConfettiOverlay(count: Int = 120) {
    val particles = remember { List(count) { Particle.random(Random.Default) } }
    var elapsed by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(Unit) {
        var start = -1L
        while (true) {
            withFrameNanos { now ->
                if (start < 0) start = now
                elapsed = (now - start) / 1_000_000_000f
            }
        }
    }

    Canvas(modifier = Modifier.fillMaxSize()) {
        val t = elapsed
        for (p in particles) {
            val age = t - p.delay
            if (age <= 0f) continue
            val x = (p.x0 + p.drift * age) * size.width
            val y = (p.y0 + p.speed * age) * size.height
            if (y > size.height) continue
            drawCircle(color = p.color, radius = p.radius, center = Offset(x, y))
        }
    }
}
