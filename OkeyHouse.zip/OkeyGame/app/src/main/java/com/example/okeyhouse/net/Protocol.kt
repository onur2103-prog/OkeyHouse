package com.example.okeyhouse.net

import android.bluetooth.BluetoothSocket
import com.example.okeyhouse.engine.GameState
import com.example.okeyhouse.engine.Move
import com.example.okeyhouse.engine.Phase
import com.example.okeyhouse.engine.Tile
import com.example.okeyhouse.engine.TileSet
import com.example.okeyhouse.engine.WinType
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.IOException
import java.util.UUID

/** Klasik Bluetooth servis kimliği. Host ve istemci aynı değeri kullanır. */
val SERVICE_UUID: UUID = UUID.fromString("8c5a7e2a-6f1b-4d7e-9a3b-0e5c2f1d6b41")
const val SERVICE_NAME = "OkeyHouse"
const val MAX_PLAYERS = 4

/** Bir oyuncunun ekranda gördüğü durum. Diğer oyuncuların eli gizli, yalnızca boyutu gelir. */
data class GameView(
    val seat: Int,
    val names: List<String>,
    val turn: Int,
    val phase: Phase,
    val winner: Int?,
    val winType: WinType?,
    val indicator: Tile,
    val pileSize: Int,
    val discards: List<Tile>,
    val hand: List<Tile>,
    val handSizes: List<Int>,
    val discardSeats: List<Int>,
)

fun GameState.viewFor(seat: Int, names: List<String>): GameView = GameView(
    seat = seat,
    names = names,
    turn = turn,
    phase = phase,
    winner = winner,
    winType = winType,
    indicator = indicator,
    pileSize = pile.size,
    discards = discards,
    hand = hands[seat],
    handSizes = hands.map { it.size },
    discardSeats = discardSeats,
)

/** Ayraç karakterlerini çıkarır, ismi kısaltır. */
fun sanitizeName(raw: String): String =
    raw.replace(Regex("[|,;]"), " ").trim().take(16).ifEmpty { "Oyuncu" }

/** Satır tabanlı protokol. Her mesaj tek satır, alanlar '|' ile ayrılır. */
sealed interface Wire {
    fun encode(): String

    /** İstemci -> Host: katılma isteği */
    data class Join(val name: String, val token: String) : Wire {
        override fun encode() = "JOIN|$name|$token"
    }

    /** Host -> İstemci: oyuncuya verilen koltuk numarası */
    data class Seat(val seat: Int) : Wire {
        override fun encode() = "SEAT|$seat"
    }

    /** Host -> İstemci: bekleme odasındaki isimler */
    data class Lobby(val names: List<String>) : Wire {
        override fun encode() = "LOBBY|${names.joinToString(";")}"
    }

    /** Host -> İstemci: güncel oyun görünümü */
    data class State(val view: GameView) : Wire {
        override fun encode(): String {
            val v = view
            return listOf(
                "STATE",
                v.seat.toString(),
                v.turn.toString(),
                v.phase.name,
                v.winner?.toString() ?: "-",
                v.winType?.name ?: "-",
                v.indicator.id.toString(),
                v.pileSize.toString(),
                v.discards.joinToString(",") { it.id.toString() },
                v.hand.joinToString(",") { it.id.toString() },
                v.handSizes.joinToString(","),
                v.names.joinToString(";"),
                v.discardSeats.joinToString(","),
            ).joinToString("|")
        }
    }

    /** İstemci -> Host: hamle */
    data class Play(val move: Move) : Wire {
        override fun encode(): String = when (move) {
            Move.DrawFromPile -> "PLAY|DRAW_PILE"
            Move.DrawFromDiscard -> "PLAY|DRAW_DISCARD"
            is Move.Discard -> "PLAY|DISCARD|${move.tileId}"
        }
    }

    /** Host -> İstemci: hata metni */
    data class Error(val text: String) : Wire {
        override fun encode() = "ERROR|$text"
    }

    companion object {
        fun decode(line: String): Wire? = runCatching { parse(line) }.getOrNull()

        private fun ids(s: String): List<Tile> =
            s.split(",").filter { it.isNotEmpty() }.map { TileSet.byId(it.toInt()) }

        private fun parse(line: String): Wire {
            val p = line.split("|")
            return when (p[0]) {
                "JOIN" -> Join(p[1], p[2])
                "SEAT" -> Seat(p[1].toInt())
                "LOBBY" -> Lobby(p[1].split(";"))
                "STATE" -> State(
                    GameView(
                        seat = p[1].toInt(),
                        names = p[11].split(";"),
                        turn = p[2].toInt(),
                        phase = Phase.valueOf(p[3]),
                        winner = p[4].takeIf { it != "-" }?.toInt(),
                        winType = p[5].takeIf { it != "-" }?.let { WinType.valueOf(it) },
                        indicator = TileSet.byId(p[6].toInt()),
                        pileSize = p[7].toInt(),
                        discards = ids(p[8]),
                        hand = ids(p[9]),
                        handSizes = p[10].split(",").map { it.toInt() },
                        discardSeats = p[12].split(",").filter { it.isNotEmpty() }.map { it.toInt() },
                    )
                )
                "PLAY" -> Play(parseMove(p.drop(1)))
                "ERROR" -> Error(p.drop(1).joinToString("|"))
                else -> throw IllegalArgumentException("Bilinmeyen mesaj")
            }
        }

        private fun parseMove(p: List<String>): Move = when (p[0]) {
            "DRAW_PILE" -> Move.DrawFromPile
            "DRAW_DISCARD" -> Move.DrawFromDiscard
            "DISCARD" -> Move.Discard(p[1].toInt())
            else -> throw IllegalArgumentException("Bilinmeyen hamle")
        }
    }
}

/** Yazma tarafı. Aynı anda birden fazla yazmayı engellemek için synchronized. */
internal class Link(private val socket: BluetoothSocket, private val writer: BufferedWriter) {
    @Synchronized
    fun send(wire: Wire) {
        try {
            writer.write(wire.encode())
            writer.newLine()
            writer.flush()
        } catch (e: IOException) {
            // Bağlantı kopmuşsa okuma tarafı zaten bunu fark eder.
        }
    }

    fun close() {
        try {
            socket.close()
        } catch (e: IOException) {
            // Zaten kapalı.
        }
    }
}

internal fun readWire(reader: BufferedReader): Wire? {
    val line: String = try {
        reader.readLine() ?: return null
    } catch (e: IOException) {
        return null
    }
    return Wire.decode(line)
}
