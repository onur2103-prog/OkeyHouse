package com.example.okeyhouse.net

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import com.example.okeyhouse.engine.Move
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.IOException
import java.util.UUID

/**
 * İstemci. Eşleşmiş bir host'a bağlanır. Bağlantı koparsa aynı host'a
 * [RECONNECT_WINDOW_MS] boyunca otomatik olarak yeniden bağlanmayı dener.
 */
@SuppressLint("MissingPermission")
class GameClient(private val scope: CoroutineScope) {

    private var socket: BluetoothSocket? = null
    private var link: Link? = null
    private var device: BluetoothDevice? = null
    private var playerName = "Oyuncu"

    @Volatile
    private var userLeft = false

    private val _view = MutableStateFlow<GameView?>(null)
    val view: StateFlow<GameView?> = _view.asStateFlow()

    private val _lobby = MutableStateFlow<List<String>>(emptyList())
    val lobby: StateFlow<List<String>> = _lobby.asStateFlow()

    private val _seat = MutableStateFlow(-1)
    val seat: StateFlow<Int> = _seat.asStateFlow()

    private val _status = MutableStateFlow("")
    val status: StateFlow<String> = _status.asStateFlow()

    /** Bağlanır. Başarısızsa false döner ve [status] nedenini anlatır. */
    suspend fun connect(device: BluetoothDevice, name: String): Boolean {
        this.device = device
        playerName = sanitizeName(name)
        userLeft = false
        return open()
    }

    fun play(move: Move) {
        link?.send(Wire.Play(move))
    }

    /** Bitiren oyuncu ıstakasının dizilimini ev sahibine gönderir. */
    fun sendLayout(slots: List<Int?>) {
        link?.send(Wire.Layout(slots))
    }

    fun disconnect() {
        userLeft = true
        link?.close()
        link = null
        socket = null
    }

    private suspend fun open(): Boolean = withContext(Dispatchers.IO) {
        val dev = device ?: return@withContext false
        _status.value = "Bağlanıyor…"
        val s = connectSocket(dev)
        if (s == null) {
            _status.value = "Bağlanılamadı. Ev sahibi \"Masa kur\" dedi mi ve telefonlar eşleşmiş mi kontrol et."
            return@withContext false
        }
        socket = s
        val reader = s.inputStream.bufferedReader()
        val l = Link(s, s.outputStream.bufferedWriter())
        link = l
        l.send(Wire.Join(playerName, sessionToken))
        scope.launch(Dispatchers.IO) { listen(reader) }
        true
    }

    /**
     * Önce servis kaydıyla bağlanmayı dener. Bazı telefonlarda bu çalışmaz;
     * o zaman doğrudan 1. kanal üzerinden dener. Bağlanamazsa null döner.
     */
    private fun connectSocket(dev: BluetoothDevice): BluetoothSocket? {
        val attempts: List<() -> BluetoothSocket?> = listOf(
            { dev.createInsecureRfcommSocketToServiceRecord(SERVICE_UUID) },
            { dev.createRfcommSocketToServiceRecord(SERVICE_UUID) },
            {
                dev.javaClass
                    .getMethod("createInsecureRfcommSocket", Int::class.javaPrimitiveType)
                    .invoke(dev, 1) as BluetoothSocket
            },
        )
        for (make in attempts) {
            val s = runCatching { make() }.getOrNull() ?: continue
            if (runCatching { s.connect() }.isSuccess) return s
            runCatching { s.close() }
        }
        return null
    }

    private suspend fun listen(reader: BufferedReader) {
        while (true) {
            val wire = readWire(reader) ?: break
            when (wire) {
                is Wire.Seat -> _seat.value = wire.seat
                is Wire.Lobby -> _lobby.value = wire.names
                is Wire.State -> _view.value = wire.view
                is Wire.Error -> _status.value = wire.text
                else -> Unit
            }
        }
        if (!userLeft) reconnect()
    }

    private suspend fun reconnect() {
        val deadline = System.currentTimeMillis() + RECONNECT_WINDOW_MS
        while (!userLeft && System.currentTimeMillis() < deadline) {
            _status.value = "Bağlantı koptu, yeniden bağlanılıyor…"
            delay(RETRY_MS)
            if (userLeft) return
            if (open()) {
                _status.value = ""
                return
            }
        }
        if (!userLeft) _status.value = "Bağlantı kurulamadı. Masadan çıkıp yeniden katıl."
    }

    companion object {
        private const val RECONNECT_WINDOW_MS = 120_000L
        private const val RETRY_MS = 3_000L

        /** Uygulama açık kaldığı sürece aynı oyuncu kimliği; koltuğa geri dönmek için kullanılır. */
        private val sessionToken: String = UUID.randomUUID().toString()

        /** Eşleşmiş cihazlar. BLUETOOTH_CONNECT izni alındıktan sonra çağrılmalı. */
        fun pairedDevices(adapter: BluetoothAdapter): List<BluetoothDevice> =
            adapter.bondedDevices?.toList().orEmpty()
    }
}
