package com.example.okeyhouse.engine

/**
 * Kazanma kontrolü: 14 taş, 4 adet per/seri ve 1 çift olarak dizilebiliyor mu?
 * Jokerler (okey ve sahte okey) her taşın yerine geçebilir.
 * Per: aynı sayı, farklı renk, 3 veya 4 taş.
 * Seri: aynı renk, ardışık sayılar, en az 3 taş (13'ten 1'e sarılmaz).
 * Çift: aynı renk ve sayıdan 2 taş.
 */
object WinChecker {

    fun isWinning(tiles: List<Tile>, isJoker: (Tile) -> Boolean): Boolean {
        if (tiles.size != 14) return false
        val counts = Array(4) { IntArray(14) }
        var jokers = 0
        for (t in tiles) {
            if (isJoker(t)) jokers++ else counts[t.color.ordinal][t.value]++
        }
        return solve(counts, jokers, melds = 4, pair = true)
    }

    /** Çifte: 14 taş 7 çift. Her çift aynı renk ve sayıdan iki taş; jokerler tek kalanları tamamlar. */
    fun isSevenPairs(tiles: List<Tile>, isJoker: (Tile) -> Boolean): Boolean {
        if (tiles.size != 14) return false
        val counts = IntArray(4 * 14)
        var jokers = 0
        for (t in tiles) {
            if (isJoker(t)) jokers++ else counts[t.color.ordinal * 14 + t.value]++
        }
        val singles = counts.count { it % 2 == 1 }
        // Jokerler tek kalanları tamamlar; kalan jokerler kendi aralarında çift olur.
        return jokers >= singles
    }

    /** Normal bitiş (4 dizi + çift) ya da çifte bitişi. */
    fun canWin(tiles: List<Tile>, isJoker: (Tile) -> Boolean): Boolean =
        isWinning(tiles, isJoker) || isSevenPairs(tiles, isJoker)

    private fun solve(c: Array<IntArray>, j: Int, melds: Int, pair: Boolean): Boolean {
        if (melds == 0 && !pair) return j == 0 && c.all { row -> row.all { it == 0 } }

        // Gerçek taşların en küçük sayılısını al. Bu taş mutlaka bir dizide olmalı.
        var col = -1
        var v = -1
        search@ for (value in 1..13) {
            for (color in 0..3) {
                if (c[color][value] > 0) {
                    col = color
                    v = value
                    break@search
                }
            }
        }
        if (v == -1) return true // Sadece jokerler kaldı; slot sayıları toplamla uyumlu.

        val base = Array(4) { c[it].copyOf() }
        base[col][v]--

        // Çift seçeneği
        if (pair && place(base, j, listOf(col to v)) { nc, nj -> solve(nc, nj, melds, false) }) {
            return true
        }

        if (melds > 0) {
            // Per seçenekleri: taşın rengi + diğer renklerden 2 veya 3 tane
            val others = (0..3).filter { it != col }
            for (mask in 0 until 8) {
                val chosen = others.filterIndexed { i, _ -> (mask shr i) and 1 == 1 }
                if (chosen.size !in 2..3) continue
                val cells = chosen.map { it to v }
                if (place(base, j, cells) { nc, nj -> solve(nc, nj, melds - 1, pair) }) return true
            }
            // Seri seçenekleri: v'yi içeren her aralık (uzunluk en az 3)
            for (s in 1..v) {
                for (e in maxOf(v, s + 2)..13) {
                    val cells = (s..e).filter { it != v }.map { col to it }
                    if (place(base, j, cells) { nc, nj -> solve(nc, nj, melds - 1, pair) }) return true
                }
            }
        }
        return false
    }

    /**
     * Her hücre için gerçek taş veya joker kullanmayı dener (geri izleme ile).
     * Hepsi yerleşince k çağrılır.
     */
    private fun place(
        c: Array<IntArray>,
        j: Int,
        cells: List<Pair<Int, Int>>,
        k: (Array<IntArray>, Int) -> Boolean
    ): Boolean = placeFrom(c, j, cells, 0, k)

    private fun placeFrom(
        c: Array<IntArray>,
        j: Int,
        cells: List<Pair<Int, Int>>,
        i: Int,
        k: (Array<IntArray>, Int) -> Boolean
    ): Boolean {
        if (i == cells.size) return k(c, j)
        val (color, value) = cells[i]
        if (c[color][value] > 0) {
            c[color][value]--
            val ok = placeFrom(c, j, cells, i + 1, k)
            c[color][value]++
            if (ok) return true
        }
        return j > 0 && placeFrom(c, j - 1, cells, i + 1, k)
    }
}
