package com.example.okeyhouse.engine

import kotlin.math.abs

/** Basit ama makul bir bot: kazanabiliyorsa bitirir, yoksa en az işe yarayan taşı atar. */
object Bot {

    fun chooseMove(s: GameState, player: Int): Move {
        val hand = s.hands[player]
        val okey = s.okey
        val isJoker = { t: Tile -> TileSet.isJoker(t, okey) }

        return when (s.phase) {
            Phase.DRAW -> {
                val top = s.discards.lastOrNull()
                val takeTop = top != null && score(top, hand, isJoker) >= 2
                if (takeTop || s.pile.isEmpty()) Move.DrawFromDiscard else Move.DrawFromPile
            }

            Phase.DISCARD -> {
                // Bitirebilecek bir atış varsa onu yap
                hand.firstOrNull { t ->
                    WinChecker.canWin(hand - t, isJoker)
                }?.let { return Move.Discard(it.id) }

                // Jokerleri mümkünse atma; en az puanlı taşı at
                val candidates = hand.filterNot(isJoker).ifEmpty { hand }
                val worst = candidates.minBy { score(it, hand - it, isJoker) }
                Move.Discard(worst.id)
            }

            Phase.FINISHED -> throw IllegalStateException("Oyun bitti")
        }
    }

    /** Taşın elde kaç taşla eşleşme (per veya seri) potansiyeli olduğu. */
    private fun score(t: Tile, others: List<Tile>, isJoker: (Tile) -> Boolean): Int {
        if (isJoker(t)) return 100
        return others.count { o ->
            !isJoker(o) && (
                o.value == t.value ||
                    (o.color == t.color && abs(o.value - t.value) <= 2)
                )
        }
    }
}
