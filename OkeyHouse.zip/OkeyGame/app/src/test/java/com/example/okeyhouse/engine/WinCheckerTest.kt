package com.example.okeyhouse.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WinCheckerTest {

    private fun t(id: Int, color: TileColor, value: Int) = Tile(id, color, value)

    // 14 taş, 4 per/seri: seri (kırmızı 1-3), seri (kırmızı 4-6), per (7 x dört renk), per (13 x dört renk)
    // Normal bitişte çift şartı yok; 14 taşın tamamı 4 dizilime oturmalı.
    private fun winningHand(): List<Tile> = listOf(
        t(1, TileColor.RED, 1), t(2, TileColor.RED, 2), t(3, TileColor.RED, 3),
        t(4, TileColor.RED, 4), t(5, TileColor.RED, 5), t(6, TileColor.RED, 6),
        t(7, TileColor.RED, 7), t(8, TileColor.BLUE, 7), t(9, TileColor.BLACK, 7), t(10, TileColor.YELLOW, 7),
        t(11, TileColor.RED, 13), t(12, TileColor.BLUE, 13), t(13, TileColor.BLACK, 13), t(14, TileColor.YELLOW, 13),
    )

    private val noJoker: (Tile) -> Boolean = { false }

    @Test
    fun winningHandIsDetected() {
        assertTrue(WinChecker.isWinning(winningHand(), noJoker))
    }

    @Test
    fun jokerReplacesMissingTile() {
        val hand = winningHand().toMutableList()
        // Kırmızı 10 yerine joker koy (id 0 joker kabul edilir)
        hand[8] = Tile(0, TileColor.BLACK, 0, isFake = true)
        assertTrue(WinChecker.isWinning(hand) { it.id == 0 })
    }

    @Test
    fun brokenPairIsNotWinning() {
        val hand = winningHand().toMutableList()
        hand[13] = t(14, TileColor.BLUE, 13)
        assertFalse(WinChecker.isWinning(hand, noJoker))
    }

    @Test
    fun wrongTileCountIsNotWinning() {
        assertFalse(WinChecker.isWinning(winningHand().dropLast(1), noJoker))
    }

    private fun sevenPairs(): MutableList<Tile> {
        val spec = listOf(
            TileColor.RED to 1, TileColor.RED to 2, TileColor.BLUE to 3, TileColor.BLACK to 5,
            TileColor.YELLOW to 7, TileColor.RED to 9, TileColor.BLUE to 12
        )
        var id = 100
        return spec.flatMap { (c, v) -> listOf(t(id++, c, v), t(id++, c, v)) }.toMutableList()
    }

    @Test
    fun sevenPairsWin() {
        assertTrue(WinChecker.isSevenPairs(sevenPairs(), noJoker))
    }

    @Test
    fun sevenPairsWithJokerWin() {
        val hand = sevenPairs()
        hand[13] = Tile(0, TileColor.BLACK, 0, isFake = true)
        assertTrue(WinChecker.isSevenPairs(hand) { it.id == 0 })
    }

    @Test
    fun brokenPairsNotWin() {
        val hand = sevenPairs()
        hand[13] = t(200, TileColor.YELLOW, 13)
        assertFalse(WinChecker.isSevenPairs(hand, noJoker))
    }

    @Test
    fun okeyIsNextValueWithWrapAround() {
        assertEquals(TileColor.RED to 5, TileSet.okeyOf(t(0, TileColor.RED, 4)))
        assertEquals(TileColor.BLUE to 1, TileSet.okeyOf(t(0, TileColor.BLUE, 13)))
    }
}
