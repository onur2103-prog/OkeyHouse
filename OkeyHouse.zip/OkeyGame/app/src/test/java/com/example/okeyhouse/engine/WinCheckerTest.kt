package com.example.okeyhouse.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WinCheckerTest {

    private fun t(id: Int, color: TileColor, value: Int) = Tile(id, color, value)

    // Bu elde kırmızı 12 yok; okey olarak seçildiğinde hiçbir gerçek taşı etkilemez.
    private val noOkey = TileColor.RED to 12

    // 14 taş, 4 per/seri: seri (kırmızı 1-3), seri (kırmızı 4-6), per (7 x dört renk), per (13 x dört renk)
    // Normal bitişte çift şartı yok; 14 taşın tamamı 4 dizilime oturmalı.
    private fun winningHand(): MutableList<Tile> = mutableListOf(
        t(1, TileColor.RED, 1), t(2, TileColor.RED, 2), t(3, TileColor.RED, 3),
        t(4, TileColor.RED, 4), t(5, TileColor.RED, 5), t(6, TileColor.RED, 6),
        t(7, TileColor.RED, 7), t(8, TileColor.BLUE, 7), t(9, TileColor.BLACK, 7), t(10, TileColor.YELLOW, 7),
        t(11, TileColor.RED, 13), t(12, TileColor.BLUE, 13), t(13, TileColor.BLACK, 13), t(14, TileColor.YELLOW, 13),
    )

    @Test
    fun winningHandIsDetected() {
        assertTrue(WinChecker.isWinning(winningHand(), noOkey))
    }

    @Test
    fun realOkeyTileReplacesMissingTile() {
        val hand = winningHand()
        // Gerçek okey (kırmızı 12) kırmızı 1'in yerine geçer
        hand[0] = Tile(0, TileColor.RED, 12)
        assertTrue(WinChecker.isWinning(hand, TileColor.RED to 12))
    }

    @Test
    fun fakeOkeyActsInOkeyColor() {
        val hand = winningHand()
        // Okey siyah 7 ise sahte okey siyah renginde bir taşın (burada siyah 7) yerine geçer
        hand[8] = Tile(0, TileColor.BLACK, 0, isFake = true)
        assertTrue(WinChecker.isWinning(hand, TileColor.BLACK to 7))
    }

    @Test
    fun fakeOkeyCannotActInOtherColor() {
        // Sahte okey, okeyin rengi ve sayısı olarak sayılır (okey sarı 12 ise sahte okey sarı 12 olur).
        // Kırmızı 1'i tamamlayacak bir taş yok; sahte okey başka bir sayıyı taklit edemez.
        val hand = mutableListOf(
            t(1, TileColor.RED, 1), t(2, TileColor.RED, 2), t(3, TileColor.BLUE, 5),
            t(4, TileColor.RED, 4), t(5, TileColor.RED, 5), t(6, TileColor.RED, 6),
            t(7, TileColor.RED, 7), t(8, TileColor.BLUE, 7), t(9, TileColor.BLACK, 7), t(10, TileColor.YELLOW, 7),
            t(11, TileColor.RED, 13), t(12, TileColor.BLUE, 13), t(13, TileColor.BLACK, 13),
            Tile(14, TileColor.BLACK, 0, isFake = true),
        )
        // Mavi 5 yerine sahte okey (mavi değil) kullanılamaz: okey sarı 12 olduğu için sahte okey sarı olmalı
        assertFalse(WinChecker.isWinning(hand, TileColor.YELLOW to 12))
    }

    @Test
    fun brokenPairIsNotWinning() {
        val hand = winningHand()
        hand[13] = t(14, TileColor.BLUE, 13)
        assertFalse(WinChecker.isWinning(hand, noOkey))
    }

    @Test
    fun wrongTileCountIsNotWinning() {
        assertFalse(WinChecker.isWinning(winningHand().dropLast(1), noOkey))
    }

    private fun sevenPairs(): MutableList<Tile> {
        val spec = listOf(
            TileColor.RED to 1, TileColor.RED to 2, TileColor.BLUE to 3, TileColor.BLACK to 5,
            TileColor.YELLOW to 7, TileColor.RED to 9, TileColor.BLUE to 12
        )
        var id = 100
        return spec.flatMap { (c, v) -> listOf(t(id++, c, v), t(id++, c, v)) }.toMutableList()
    }

    @Test
    fun sevenPairsWin() {
        assertTrue(WinChecker.isSevenPairs(sevenPairs(), noOkey))
    }

    @Test
    fun sevenPairsWithFakeOkeyWin() {
        val hand = sevenPairs()
        // Okey mavi 12 ise sahte okey ikinci mavi 12 olur ve çifti tamamlar
        hand[13] = Tile(0, TileColor.BLUE, 0, isFake = true)
        assertTrue(WinChecker.isSevenPairs(hand, TileColor.BLUE to 12))
    }

    @Test
    fun brokenPairsNotWin() {
        val hand = sevenPairs()
        hand[13] = t(200, TileColor.YELLOW, 13)
        assertFalse(WinChecker.isSevenPairs(hand, noOkey))
    }

    @Test
    fun wrapRunEndingAtOneIsValid() {
        // Mavi 11-12-13-1 sarmal seri (4), kırmızı 4-5-6, siyah 7-10, sarı 2-4
        val hand = mutableListOf(
            t(1, TileColor.BLUE, 11), t(2, TileColor.BLUE, 12), t(3, TileColor.BLUE, 13), t(4, TileColor.BLUE, 1),
            t(5, TileColor.RED, 4), t(6, TileColor.RED, 5), t(7, TileColor.RED, 6),
            t(8, TileColor.BLACK, 7), t(9, TileColor.BLACK, 8), t(10, TileColor.BLACK, 9), t(11, TileColor.BLACK, 10),
            t(12, TileColor.YELLOW, 2), t(13, TileColor.YELLOW, 3), t(14, TileColor.YELLOW, 4),
        )
        assertTrue(WinChecker.isWinning(hand, noOkey))
    }

    @Test
    fun threeTilePerIsValid() {
        // Per 5 (3 taş, farklı renk), seri kırmızı 1-3, seri sarı 8-11, per 12 (4 taş)
        val hand = mutableListOf(
            t(1, TileColor.RED, 5), t(2, TileColor.BLUE, 5), t(3, TileColor.BLACK, 5),
            t(4, TileColor.RED, 1), t(5, TileColor.RED, 2), t(6, TileColor.RED, 3),
            t(7, TileColor.YELLOW, 8), t(8, TileColor.YELLOW, 9), t(9, TileColor.YELLOW, 10), t(10, TileColor.YELLOW, 11),
            t(11, TileColor.RED, 12), t(12, TileColor.BLUE, 12), t(13, TileColor.BLACK, 12), t(14, TileColor.YELLOW, 12),
        )
        assertTrue(WinChecker.isWinning(hand, TileColor.YELLOW to 13))
    }

    @Test
    fun okeyIsNextValueWithWrapAround() {
        assertEquals(TileColor.RED to 5, TileSet.okeyOf(t(0, TileColor.RED, 4)))
        assertEquals(TileColor.BLUE to 1, TileSet.okeyOf(t(0, TileColor.BLUE, 13)))
    }
}
