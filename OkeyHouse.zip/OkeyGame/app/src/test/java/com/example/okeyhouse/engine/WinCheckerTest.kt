package com.example.okeyhouse.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WinCheckerTest {

    private fun t(id: Int, color: TileColor, value: Int) = Tile(id, color, value)

    // Bu elde kırmızı 12 yok; okey olarak seçildiğinde hiçbir gerçek taşı etkilemez.
    private val noOkey = TileColor.RED to 12

    // 14 taş, 4 per/seri: seri (kırmızı 1-3), seri (kırmızı 4-6), per (7 x dört renk), per (13 x dört renk)
    // Normal bitişte çift şartı yok; 14 taşın tamamı 4 dizilime oturmalı.
    private fun winningHand(): MutableList<Tile> = mutableListOf(
        t(1, TileColor.RED, 1), t(2, TileColor.RED, 2), t(3, TileColor.RED, 3),
        t(4, TileColor.RED, 4), t(5, TileColor.RED, 5), t(6, TileColor.RED, 6),
        t(7, TileColor.RED, 7), t(8, TileColor.BLUE, 7), t(9, TileColor.BLACK, 7), t(10, TileColor.YELLOW, 7),
        t(11, TileColor.RED, 13), t(12, TileColor.BLUE, 13), t(13, TileColor.BLACK, 13), t(14, TileColor.YELLOW, 13),
    )

    @Test
    fun winningHandIsDetected() {
        assertTrue(WinChecker.isWinning(winningHand(), noOkey))
    }

    @Test
    fun realOkeyTileReplacesMissingTile() {
        val hand = winningHand()
        // Gerçek okey (kırmızı 12) kırmızı 1'in yerine geçer
        hand[0] = Tile(0, TileColor.RED, 12)
        assertTrue(WinChecker.isWinning(hand, TileColor.RED to 12))
    }

    @Test
    fun fakeOkeyActsAsOkeyTileOnly() {
        val hand = winningHand()
        // Sahte okey, okey taşı siyah 7 ise siyah 7 yerine geçer
        hand[8] = Tile(0, TileColor.BLACK, 0, isFake = true)
        assertTrue(WinChecker.isWinning(hand, TileColor.BLACK to 7))
        // Okey kırmızı 12 ise sahte okey siyah 7 yerine geçemez
        assertFalse(WinChecker.isWinning(hand, TileColor.RED to 12))
    }

    @Test
    fun brokenPairIsNotWinning() {
        val hand = winningHand()
        hand[13] = t(14, TileColor.BLUE, 13)
        assertFalse(WinChecker.isWinning(hand, noOkey))
    }

    @Test
    fun wrongTileCountIsNotWinning() {
        assertFalse(WinChecker.isWinning(winningHand().dropLast(1), noOkey))
    }

    private fun sevenPairs(): MutableList<Tile> {
        val spec = listOf(
            TileColor.RED to 1, TileColor.RED to 2, TileColor.BLUE to 3, TileColor.BLACK to 5,
            TileColor.YELLOW to 7, TileColor.RED to 9, TileColor.BLUE to 12
        )
        var id = 100
        return spec.flatMap { (c, v) -> listOf(t(id++, c, v), t(id++, c, v)) }.toMutableList()
    }

    @Test
    fun sevenPairsWin() {
        assertTrue(WinChecker.isSevenPairs(sevenPairs(), noOkey))
    }

    @Test
    fun sevenPairsWithFakeOkeyWin() {
        val hand = sevenPairs()
        // Okey mavi 12 ise sahte okey ikinci mavi 12 olur ve çifti tamamlar
        hand[13] = Tile(0, TileColor.BLUE, 0, isFake = true)
        assertTrue(WinChecker.isSevenPairs(hand, TileColor.BLUE to 12))
    }

    @Test
    fun brokenPairsNotWin() {
        val hand = sevenPairs()
        hand[13] = t(200, TileColor.YELLOW, 13)
        assertFalse(WinChecker.isSevenPairs(hand, noOkey))
    }

    @Test
    fun okeyIsNextValueWithWrapAround() {
        assertEquals(TileColor.RED to 5, TileSet.okeyOf(t(0, TileColor.RED, 4)))
        assertEquals(TileColor.BLUE to 1, TileSet.okeyOf(t(0, TileColor.BLUE, 13)))
    }
}
