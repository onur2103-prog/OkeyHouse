# OkeyHouse (Android, Bluetooth)

Tek kişilik (diğer 3 oyuncu bot) veya klasik Bluetooth ile 4 telefona kadar çok oyunculu okey.

## Kurulum

1. Android Studio'da **Open** ile bu klasörü aç.
2. Gradle senkronizasyonunu bekle.
3. Telefonda geliştirici modunu ve USB hata ayıklamayı aç, bağla, **Run** ile kur.

Testleri çalıştırmak için: `./gradlew :app:testDebugUnitTest`

## Bluetooth nasıl çalışır

- Bir telefon **Sunucu (Host)** olur, diğerleri **İstemci (Client)** olarak bağlanır.
- Telefonlar önceden Ayarlar > Bluetooth'tan eşleştirilmiş olmalıdır.
- Sunucu eksik koltukları botlarla doldurabilir. Tek kişi de oynayabilir.
- Oyun durumu sunucuda tutulur; istemciler yalnızca hamlelerini gönderir.

## Kurallar

- 106 taş: 2 kopya x 4 renk x 1-13 + 2 sahte okey.
- Gösterge taşının bir üstü okey olur (13'ten sonra 1).
- Okey taşı ve sahte okey her taşın yerine geçer.
- Normal bitiş: 14 taş, 4 adet per/seri (en az 3 taş) + 1 çift.
- Çifte bitiş: 14 taş, 7 çift. Jokerler eksik taşı tamamlayabilir.
- Okey ile bitiş: Normal veya çifte bitişte elde gerçek okey taşı varsa. Sahte okey tek başına yetmez, ama dizilişte kullanılabilir.
- Başlayan oyuncu 15 taşla başlar. Deste bitince oyun berabere biter.

Henüz yok: "el açma" ve "gelir" gibi varyantlar.

## Proje yapısı

```
app/src/main/java/com/example/okeyhouse/
  engine/   Taş modeli, kazanma kontrolü, oyun akışı, bot   (saf Kotlin, test edilebilir)
  net/      Klasik Bluetooth sunucu/istemci ve mesaj protokolü
  ui/       Compose arayüzü ve MainActivity
app/src/test/   Kazanma kontrolü testleri
```
